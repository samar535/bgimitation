// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBt-J80fYOrrmJU6kpNJJz_17sVDyEVpIQ",
  authDomain: "bgimitation.firebaseapp.com",
  projectId: "bgimitation",
  storageBucket: "bgimitation.firebasestorage.app",
  messagingSenderId: "728515671790",
  appId: "1:728515671790:web:db66ac40dfaf25ee88a5ff"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);